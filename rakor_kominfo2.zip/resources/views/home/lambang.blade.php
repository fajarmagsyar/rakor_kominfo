@extends('home.layouts.main')
@section('isi')

        <!-- ======= About Section ======= -->
        <section id="about" class="about">
            <div class="container" data-aos="fade-up">

                <div class="section-header">
                    <h2 style="padding-top: 50px;">Lambang</h2>
                    <hr>
                </div>

                <div class="text-center mx-auto" data-aos="fade-up" data-aos-delay="200">
                    <img src="/assets/img/logo-apeksi.png" class="img-fluid" alt="">
                </div>

            </div>
        </section><!-- End About Section -->

       
    </main><!-- End #main -->
@endsection
